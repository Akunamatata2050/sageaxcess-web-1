<p>This content is loaded from an external source using AJAX</p>

<p>PHP Generated Timestamp: <em>
<?php 
	$date = new DateTime();
	echo $date->format('Y-m-d H:i:s') . "\n";
?>
</em></p>